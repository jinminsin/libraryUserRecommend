package com.slave_mk14.libraryuserrecommendation;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class Comment_Adapter extends ArrayAdapter {

    private Context context;
    private List<Comment_Item> list;

    public Comment_Adapter(Context context, int resource, ArrayList list){
        super(context,0,list);
        this.context = context;
        this.list = list;

    }

    class ViewHolder{
        TextView pid;
        TextView subtitle;
        TextView owner;
        TextView createDate;
        TextView password;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        final ViewHolder viewHolder;

        if(convertView == null){
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            convertView = layoutInflater.inflate(R.layout.detail_listdata,parent,false);
        }

        viewHolder = new ViewHolder();
        viewHolder.pid = (TextView)convertView.findViewById(R.id.d_id);
        viewHolder.subtitle = (TextView)convertView.findViewById(R.id.d_subtitle);
        viewHolder.owner = (TextView)convertView.findViewById(R.id.d_owner);
        viewHolder.createDate = (TextView)convertView.findViewById(R.id.d_createDate);
        viewHolder.password = (TextView)convertView.findViewById(R.id.d_password);

        final Comment_Item comment_item = (Comment_Item)list.get(position);

        viewHolder.pid.setText(comment_item.getPid());
        viewHolder.subtitle.setText(comment_item.getSubtitle());
        viewHolder.owner.setText(comment_item.getOwner());
        viewHolder.createDate.setText(comment_item.getCreateDate());
        viewHolder.password.setText(comment_item.getPassword());

        return convertView;


    }
}
