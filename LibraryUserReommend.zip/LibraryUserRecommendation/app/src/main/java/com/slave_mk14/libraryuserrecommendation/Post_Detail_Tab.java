package com.slave_mk14.libraryuserrecommendation;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class Post_Detail_Tab extends Fragment {

    //댓글을 보고 쓰는곳
    ArrayList<Comment_Item> comment_items = new ArrayList<>();
    ListView comment_listView;
    private static Comment_Adapter Comment_Adapter;
    private static String url = "http://39.112.64.186/";


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.community_post_detail,container,false);
        comment_listView = (ListView)rootView.findViewById(R.id.Detail_ListView);

        Response.Listener<String> responseListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                String Commnet = "{\"result\" : [{\"pid\":\"pid\",\"subtitle\":\"subtitle\",\"owner\":\"owner\",\"createDate\":\"createDate\",\"password\":\"password\"}]}";
                try{
                    JSONObject jsonObject = new JSONObject(Commnet);
                    JSONArray jsonArray = jsonObject.getJSONArray("result");
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject obj = jsonArray.getJSONObject(i);
                        Comment_Item item = new Comment_Item(obj.getString("pid"),obj.getString("subtitle"),obj.getString("owner"),obj.getString("createDate"),obj.getString("password"));
                        comment_items.add(item);
                        Log.e("확인확인",""+item.getPid());
                    }
                    Comment_Adapter = new Comment_Adapter(getContext(),0,comment_items);
                    comment_listView.setAdapter(Comment_Adapter);
                    comment_listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            Comment_Item item = (Comment_Item)parent.getItemAtPosition(position);
                            getFragmentManager().beginTransaction().replace(R.id.yeah, new Post_Detail_Tab()).commit();
                        }
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        DBResponse.searchCommentResponse(requestQueue,0,responseListener);

        return rootView;
    }
}
