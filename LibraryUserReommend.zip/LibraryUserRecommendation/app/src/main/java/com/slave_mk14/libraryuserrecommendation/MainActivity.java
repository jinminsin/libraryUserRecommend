package com.slave_mk14.libraryuserrecommendation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView a;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TabLayout tab = findViewById(R.id.tab);

        ArrayList<Integer> images = new ArrayList<>();
        images.add(R.drawable.ic_launcher_foreground);
        images.add(R.drawable.ic_launcher_foreground);
        images.add(R.drawable.ic_launcher_foreground);
        images.add(R.drawable.ic_launcher_foreground);

        for(int i = 0; i < 4; i++)
            tab.getTabAt(i).setIcon(images.get(i));

        getSupportFragmentManager().beginTransaction().replace(R.id.yeah,new Community_Tab()).commit();

        /*RequestQueue q = Volley.newRequestQueue(this);
        Response.Listener<String> responseListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("Result","["+response+"]");
                           }
        };

        DBResponse.searchCommunityResponse(q, responseListener);*/
    }
}