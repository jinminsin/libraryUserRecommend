package com.slave_mk14.libraryuserrecommendation;

public class User {
    int seedid;//시드 아이디
    String id; //아이디

    public int getSeedid() {
        return seedid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setSeedid(int seedid) {
        this.seedid = seedid;
    }
}
