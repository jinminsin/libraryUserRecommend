package com.example.myapplication0;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;



public class Post_Detail extends Fragment {

    EditText post_editText;
    EditText post_titleText;
    Button button;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_post__detail,null);
        post_editText = (EditText)view.findViewById(R.id.title_post_edit);
        post_titleText = (EditText)view.findViewById(R.id.title_post_edit);
        button = (Button)view.findViewById(R.id.post_button);

        View.OnClickListener listener = new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.yeah, new Post()).commit();

            }};

        return view;
    }


}